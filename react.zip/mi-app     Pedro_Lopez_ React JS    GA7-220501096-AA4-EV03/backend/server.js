const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = mysql.createConnection({
  host: "localhost",
  user: "root", // Cambia esto
  password: "", // Cambia esto
  database: "baseok", // Cambia esto
});

db.connect((err) => {
  if (err) {
    console.error("Error de conexión a la base de datos:", err);
    return;
  }
  console.log("Conexión a la base de datos establecida.");
});

// Ruta para registrar un usuario
app.post("/register", (req, res) => {
  const {
    nombreCompleto,
    correo,
    password,
    repetirPassword,
    telefono,
    direccion,
  } = req.body;

  if (password !== repetirPassword) {
    return res.status(400).send("Las contraseñas no coinciden.");
  }

  const hashedPassword = bcrypt.hashSync(password, 8);

  db.query(
    "INSERT INTO usuarios (nombreCompleto, password, telefono, correo, direccion) VALUES (?, ?, ?, ?, ?)",
    [nombreCompleto, hashedPassword, telefono, correo, direccion],
    (err, result) => {
      if (err) {
        console.error(err);
        return res
          .status(500)
          .send("Error en la base de datos: " + err.message);
      }
      res.status(200).send("Usuario registrado.");
    }
  );
});

// Ruta para iniciar sesión
app.post("/login", (req, res) => {
  const { nombreCompleto, password } = req.body;

  db.query(
    "SELECT * FROM usuarios WHERE nombreCompleto = ?",
    [nombreCompleto],
    (err, results) => {
      if (err) return res.status(500).send("Error en la base de datos.");
      if (results.length === 0)
        return res.status(404).send("Usuario no encontrado.");

      const user = results[0];
      const passwordIsValid = bcrypt.compareSync(password, user.password);

      if (!passwordIsValid)
        return res.status(401).send("Contraseña incorrecta.");

      const token = jwt.sign({ id: user.id }, "tu_secreto", {
        expiresIn: 86400,
      });
      res.status(200).send({ auth: true, token });
    }
  );
});

// Ruta para obtener todos los usuarios
app.get("/usuarios", (req, res) => {
  db.query(
    "SELECT id, nombreCompleto, correo FROM usuarios",
    (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error en la base de datos.");
      }
      res.json(results);
    }
  );
});

// Ruta para agregar un nuevo usuario
app.post("/usuarios", (req, res) => {
  const { nombreCompleto, correo } = req.body;

  db.query(
    "INSERT INTO usuarios (nombreCompleto, correo) VALUES (?, ?)",
    [nombreCompleto, correo],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error en la base de datos.");
      }
      res.status(201).send("Usuario agregado.");
    }
  );
});

// Ruta para actualizar un usuario
app.put("/usuarios/:id", (req, res) => {
  const { id } = req.params;
  const { nombreCompleto, correo } = req.body;

  db.query(
    "UPDATE usuarios SET nombreCompleto = ?, correo = ? WHERE id = ?",
    [nombreCompleto, correo, id],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error en la base de datos.");
      }
      res.send("Usuario actualizado.");
    }
  );
});

// Ruta para eliminar un usuario
app.delete("/usuarios/:id", (req, res) => {
  const { id } = req.params;

  db.query("DELETE FROM usuarios WHERE id = ?", [id], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Error en la base de datos.");
    }
    res.send("Usuario eliminado.");
  });
});

// Ruta para obtener médicos
app.get("/medico", (req, res) => {
  db.query(
    "SELECT id, nombre, especialidad, telefono FROM medico",
    (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error en la base de datos.");
      }
      res.json(results);
    }
  );
});

// Ruta para agendar una cita
app.post("/citas", (req, res) => {
  const { idMedico, fecha, hora, usuarioId } = req.body;

  db.query(
    "INSERT INTO citas (idMedico, fecha, hora, usuarioId) VALUES (?, ?, ?, ?)",
    [idMedico, fecha, hora, usuarioId],
    (err, result) => {
      if (err) {
        console.error(err);
        return res
          .status(500)
          .send("Error en la base de datos: " + err.message);
      }
      res.status(200).send("Cita agendada correctamente.");
    }
  );
});

// Ruta para obtener citas con información del médico
app.get("/citas", (req, res) => {
  const query = `
      SELECT citas.id, citas.fecha, citas.hora, 
             medico.nombre AS medicoNombre, 
             medico.especialidad, 
             medico.telefono 
      FROM citas 
      JOIN medico ON citas.idMedico = medico.id;
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Error en la base de datos.");
    }
    res.json(results);
  });
});

// Ruta para editar una cita
app.put("/citas/:id", (req, res) => {
  const { id } = req.params;
  const { idMedico, fecha, hora, usuarioId } = req.body;

  db.query(
    "UPDATE citas SET idMedico = ?, fecha = ?, hora = ?, usuarioId = ? WHERE id = ?",
    [idMedico, fecha, hora, usuarioId, id],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error en la base de datos.");
      }
      res.send("Cita actualizada.");
    }
  );
});

// Ruta para eliminar una cita
app.delete("/citas/:id", (req, res) => {
  const { id } = req.params;

  db.query("DELETE FROM citas WHERE id = ?", [id], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Error en la base de datos.");
    }
    res.send("Cita eliminada.");
  });
});

app.listen(3001, () => {
  console.log("Servidor corriendo en http://localhost:3001");
});
