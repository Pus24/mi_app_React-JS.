// src/components/ListarCitas.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './ListarCitas.css';

const ListarCitas = () => {
  const [citas, setCitas] = useState([]);
  const [editCita, setEditCita] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const obtenerCitas = async () => {
      try {
        const response = await axios.get('http://localhost:3001/citas');
        setCitas(response.data);
      } catch (error) {
        console.error('Error al obtener citas:', error);
      }
    };
    obtenerCitas();
  }, []);

  const handleEditClick = (cita) => {
    setEditCita(cita);
  };

  const handleDeleteClick = async (id) => {
    const confirmDelete = window.confirm('¿Estás seguro de que deseas eliminar esta cita?');
    if (confirmDelete) {
      try {
        await axios.delete(`http://localhost:3001/citas/${id}`);
        setCitas((prevCitas) => prevCitas.filter(cita => cita.id !== id));
        alert('Cita eliminada con éxito.');
      } catch (error) {
        console.error('Error al eliminar cita:', error);
        alert('Error al eliminar cita.');
      }
    }
  };

  const handleSaveClick = async () => {
    if (editCita) {
      try {
        await axios.put(`http://localhost:3001/citas/${editCita.id}`, editCita);
        setCitas((prevCitas) => prevCitas.map(cita => (cita.id === editCita.id ? editCita : cita)));
        alert('Cita actualizada con éxito.');
        setEditCita(null); // Restablecer estado de edición
      } catch (error) {
        console.error('Error al guardar cambios:', error);
        alert('Error al guardar cambios.');
      }
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditCita({ ...editCita, [name]: value });
  };

  return (
    <div className="listar-citas-container">
      <h2>Citas Agendadas</h2>
      <div className="citas-list">
        {citas.map(cita => (
          <div key={cita.id} className="cita-container">
            {editCita && editCita.id === cita.id ? (
              <div>
                <input
                  type="text"
                  name="idMedico"
                  value={editCita.idMedico || ''}
                  onChange={handleChange}
                  placeholder="ID Médico"
                />
                <input
                  type="text"
                  name="fecha"
                  value={editCita.fecha || ''}
                  onChange={handleChange}
                  placeholder="Fecha"
                />
                <input
                  type="text"
                  name="hora"
                  value={editCita.hora || ''}
                  onChange={handleChange}
                  placeholder="Hora"
                />
                <button onClick={handleSaveClick} className="edit-button">Guardar</button>
                <button onClick={() => setEditCita(null)} className="cancel-button">Cancelar</button>
              </div>
            ) : (
              <div>
                {cita.medicoNombre ? (
                  <>
                    Médico: {cita.medicoNombre} - Especialidad: {cita.especialidad} - Teléfono: {cita.telefono} <br />
                  </>
                ) : (
                  <span>Médico no disponible</span>
                )}
                Fecha: {cita.fecha} - Hora: {cita.hora}
                <button onClick={() => handleEditClick(cita)} className="edit-button">Editar</button>
                <button onClick={() => handleDeleteClick(cita.id)} className="delete-button">Eliminar</button>
              </div>
            )}
          </div>
        ))}
      </div>
      <button onClick={() => navigate('/register')}>Registrar Nueva Cita</button>
    </div>
  );
};

export default ListarCitas;
