// src/components/AgendarCita.js
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom"; // Importa useNavigate
import "./AgendarCita.css";
import logo from "./logo.png"; // Asegúrate de tener el logo en esta ruta

const AgendarCita = ({ onCitaAgendada }) => {
  const [medicos, setMedicos] = useState([]);
  const [idMedico, setIdMedico] = useState("");
  const [fecha, setFecha] = useState("");
  const [hora, setHora] = useState("");
  const [usuarioId] = useState(""); // Asumiendo que el ID del usuario se obtiene de otra parte
  const navigate = useNavigate(); // Inicializa useNavigate

  useEffect(() => {
    const obtenerMedicos = async () => {
      try {
        const response = await axios.get("http://localhost:3001/medico");
        setMedicos(response.data);
      } catch (error) {
        console.error("Error al obtener médicos:", error);
      }
    };

    obtenerMedicos();
  }, []);

  const agendarCita = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:3001/citas", {
        idMedico,
        fecha,
        hora,
        usuarioId,
      });
      alert("Cita agendada exitosamente.");
      onCitaAgendada(); // Llama a la función onCitaAgendada para manejar el estado en el padre
      navigate("/listar-citas"); // Redirecciona a la página de listar citas
      // Resetea los campos
      setIdMedico("");
      setFecha("");
      setHora("");
    } catch (error) {
      console.error("Error al agendar cita:", error);
      alert("Error al agendar cita.");
    }
  };

  return (
    <div className="agendar-cita-container">
      <div style={styles.formContainer}>
        <h2 style={styles.title}>Agendar Cita Médica</h2>
        <form onSubmit={agendarCita}>
          <select
            value={idMedico}
            onChange={(e) => setIdMedico(e.target.value)}
            required
          >
            <option value="">Selecciona un médico</option>
            {medicos.map((medico) => (
              <option key={medico.id} value={medico.id}>
                {medico.nombre} - {medico.especialidad} (Tel: {medico.telefono})
              </option>
            ))}
          </select>
          <input
            type="date"
            value={fecha}
            onChange={(e) => setFecha(e.target.value)}
            required
          />
          <input
            type="time"
            value={hora}
            onChange={(e) => setHora(e.target.value)}
            required
          />
          <button type="submit">Agendar Cita</button>
        </form>
      </div>
      <div className="logo-container" style={styles.logoContainer}>
        <img src={logo} alt="Logo Clínica del Caribe" className="logo" style={styles.logo} />
      </div>
    </div>
  );
};

const styles = {  
  logo: {
    maxWidth: '160%', // Aumenta el tamaño del logo en un 30%
    alignItems: 'center',
    justifyContent: 'center', // Centra el logo horizontalmente
  },
  logoContainer: {
    display: 'flex',
    alignItems: 'flex-start',
    marginTop: '-50px', // Ajusta la posición vertical si es necesario
  },
  title: {
    textAlign: 'center',
    fontSize: '1.5em', // Aumenta el tamaño del título
    margin: '20px 0',
  },
  formContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: '20px',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
    position: 'relative', // Para el posicionamiento del logo
  },
};

export default AgendarCita;
