// src/components/Register.js
import React, { useState } from "react";
import axios from "axios";
import logo from "./logo.png"; // Asegúrate de tener el logo en esta ruta
import { FaFacebook, FaInstagram, FaTwitter } from "react-icons/fa"; // Instala react-icons si no lo tienes
import { useNavigate } from "react-router-dom"; // Importa useNavigate

const Register = ({ onRegister }) => {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      alert("Las contraseñas no coinciden");
      return;
    }
    axios
      .post("http://localhost:3001/register", {
        nombreCompleto: fullName,
        correo: email,
        password,
        repetirPassword: confirmPassword,
        telefono: phone,
        direccion: address,
      })
      .then((response) => {
        alert(response.data);
        onRegister();
        navigate("/login");
      })
      .catch((error) => {
        console.error(error);
        alert(
          "Error al registrar: " + (error.response?.data || "Error desconocido")
        );
      });
  };

  return (
    <div style={styles.container}>
      <div style={styles.formContainer}>
        <h1 style={styles.title}>Clínica del Caribe</h1>
        <h2 style={styles.subtitle}>Registrarse</h2>
        <form onSubmit={handleSubmit} style={styles.form}>
          <input
            type="text"
            placeholder="Nombre Completo"
            onChange={(e) => setFullName(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="email"
            placeholder="Correo Electrónico"
            onChange={(e) => setEmail(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="password"
            placeholder="Contraseña"
            onChange={(e) => setPassword(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="password"
            placeholder="Repetir Contraseña"
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="text"
            placeholder="Teléfono"
            onChange={(e) => setPhone(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="text"
            placeholder="Dirección"
            onChange={(e) => setAddress(e.target.value)}
            required
            style={styles.input}
          />
          <div style={styles.buttonContainer}>
            <button type="submit" style={styles.button}>Registrarse</button>
          </div>
        </form>
      </div>
      <div style={styles.logoWrapper}>
        <img src={logo} alt="Logo Clínica del Caribe" style={styles.logo} />
      </div>
      <div style={styles.footer}>
        <a href="https://facebook.com/clinicacaribe" target="_blank" rel="noopener noreferrer" style={{ ...styles.socialIcon, backgroundColor: '#3b5998' }}>
          <FaFacebook />
        </a>
        <a href="https://instagram.com/clinicacaribe" target="_blank" rel="noopener noreferrer" style={{ ...styles.socialIcon, backgroundColor: '#e4405f' }}>
          <FaInstagram />
        </a>
        <a href="https://twitter.com/clinicacaribe" target="_blank" rel="noopener noreferrer" style={{ ...styles.socialIcon, backgroundColor: '#1da1f2' }}>
          <FaTwitter />
        </a>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: '20px',
    maxWidth: '800px',
    margin: '0 auto',
    position: 'relative',
    minHeight: '100vh', // Para que el contenedor ocupe toda la altura
  },
  formContainer: {
    flex: 1,
    marginRight: '20px',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
  },
  title: {
    textAlign: 'center',
  },
  subtitle: {
    textAlign: 'center',
    marginBottom: '20px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
  },
  input: {
    padding: '10px',
    margin: '10px 0',
    borderRadius: '5px',
    border: '1px solid #ccc',
  },
  buttonContainer: {
    textAlign: 'center',
  },
  button: {
    padding: '10px 15px',
    borderRadius: '5px',
    border: 'none',
    backgroundColor: '#61dafb',
    color: '#fff',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },
  logoWrapper: {
    flexShrink: 0,
    marginLeft: '20px',
  },
  logo: {
    maxWidth: '80%', // Logo un 20% más pequeño
    height: 'auto',
  },
  footer: {
    position: 'absolute',
    bottom: '20px',
    right: '20px',
    display: 'flex',
    gap: '10px',
  },
  socialIcon: {
    color: '#fff', // Color de los íconos
    fontSize: '24px', // Tamaño de los íconos
    padding: '10px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '40px',
    height: '40px',
  },
};

export default Register;
