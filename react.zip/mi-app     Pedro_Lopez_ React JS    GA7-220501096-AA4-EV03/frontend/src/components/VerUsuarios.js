// src/components/VerUsuarios.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './VerUsuarios.css';

const VerUsuarios = () => {
    const [usuarios, setUsuarios] = useState([]);
    const [nombreCompleto, setNombreCompleto] = useState('');
    const [correo, setCorreo] = useState('');
    const [editando, setEditando] = useState(false);
    const [usuarioId, setUsuarioId] = useState(null);

    useEffect(() => {
        obtenerUsuarios();
    }, []);

    const obtenerUsuarios = async () => {
        try {
            const response = await axios.get('http://localhost:3001/usuarios');
            setUsuarios(response.data);
        } catch (error) {
            console.error('Error al obtener usuarios:', error);
        }
    };

    const agregarUsuario = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:3001/usuarios', { nombreCompleto, correo });
            setNombreCompleto('');
            setCorreo('');
            obtenerUsuarios();
        } catch (error) {
            console.error('Error al agregar usuario:', error);
        }
    };

    const iniciarEdicion = (usuario) => {
        setNombreCompleto(usuario.nombreCompleto);
        setCorreo(usuario.correo);
        setEditando(true);
        setUsuarioId(usuario.id);
    };

    const actualizarUsuario = async (e) => {
        e.preventDefault();
        try {
            await axios.put(`http://localhost:3001/usuarios/${usuarioId}`, { nombreCompleto, correo });
            setNombreCompleto('');
            setCorreo('');
            setEditando(false);
            setUsuarioId(null);
            obtenerUsuarios();
        } catch (error) {
            console.error('Error al actualizar usuario:', error);
        }
    };

    const eliminarUsuario = async (id) => {
        const confirmar = window.confirm("¿Estás seguro de que deseas eliminar este usuario?");
        if (!confirmar) {
            return; // Si el usuario cancela, no hacer nada
        }
        try {
            await axios.delete(`http://localhost:3001/usuarios/${id}`);
            obtenerUsuarios();
        } catch (error) {
            console.error('Error al eliminar usuario:', error);
        }
    };

    return (
        <div className="ver-usuarios-container">
            <h1>Clínica del Caribe</h1>
            <div className="form-container">
                <div className="edit-fields-container">
                    <h2>{editando ? 'Editar Usuario' : 'Agregar Usuario'}</h2>
                    <form onSubmit={editando ? actualizarUsuario : agregarUsuario}>
                        <input
                            type="text"
                            placeholder="Nombre Completo"
                            value={nombreCompleto}
                            onChange={(e) => setNombreCompleto(e.target.value)}
                            required
                        />
                        <input
                            type="email"
                            placeholder="Correo Electrónico"
                            value={correo}
                            onChange={(e) => setCorreo(e.target.value)}
                            required
                        />
                        <button type="submit">{editando ? 'Actualizar' : 'Agregar'}</button>
                    </form>
                </div>
            </div>

            <h3>Lista de Usuarios</h3>
            <div className="usuarios-list-container">
                {usuarios.map((usuario) => (
                    <div key={usuario.id} className="usuario-container">
                        {usuario.nombreCompleto} - {usuario.correo}
                        <div>
                            <button className="edit-button" onClick={() => iniciarEdicion(usuario)}>Editar</button>
                            <button className="delete-button" onClick={() => eliminarUsuario(usuario.id)}>Eliminar</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default VerUsuarios;
