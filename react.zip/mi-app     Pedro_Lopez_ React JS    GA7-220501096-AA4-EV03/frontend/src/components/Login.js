// src/components/Login.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Importa useNavigate
import './Login.css'; // Asegúrate de crear este archivo

const Login = ({ onLogin }) => { // Acepta la prop onLogin
    const [nombreCompleto, setNombreCompleto] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate(); // Inicializa useNavigate

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:3001/login', { nombreCompleto, password })
            .then(response => {
                if (response.data.auth) {
                    alert('Inicio de sesión exitoso!');
                    // Guarda el token si es necesario
                    localStorage.setItem('token', response.data.token);
                    onLogin(); // Llama a la función onLogin para cambiar el estado de autenticación
                    navigate('/agendar-cita'); // Redirecciona a Agendar Cita
                }
            })
            .catch(error => {
                console.error(error); // Para depuración
                alert('Error al iniciar sesión: ' + (error.response?.data || 'Error desconocido'));
            });
    };

    return (
        <div className="login-container">
            <h1 className="title">Clínica del Caribe</h1> {/* Título agregado aquí */}
            <form onSubmit={handleSubmit} className="login-form">
                <h2 className="subtitle">Iniciar Sesión</h2>
                <input
                    type="text"
                    placeholder="Nombre Completo"
                    onChange={(e) => setNombreCompleto(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Contraseña"
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <button type="submit">Iniciar sesión</button>
            </form>
        </div>
    );
};

export default Login;
