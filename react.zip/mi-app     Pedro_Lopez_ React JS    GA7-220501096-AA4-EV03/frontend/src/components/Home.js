// src/components/Home.js
import React from 'react';
import { useNavigate } from 'react-router-dom'; // Importa useNavigate
import './Home.css'; // Importa los estilos
import logo from "./logo.png"; // Asegúrate de tener el logo en esta ruta
import { FaFacebook, FaInstagram, FaTwitter } from "react-icons/fa"; // Asegúrate de tener react-icons instalado

function Home() {
  const navigate = useNavigate(); // Inicializa useNavigate

  return (
    <div className="home-container">
      <h1 className="home-title">Bienvenido a la Página Principal</h1>
      <p className="home-text">Por favor elige una opción: Iniciar Sesión o Registrarte.</p>
      <div>
        <button onClick={() => navigate('/login')} className="login-button">Iniciar Sesión</button>
        <button onClick={() => navigate('/register')} className="register-button">Registrarse</button>
      </div>
      <div style={styles.logoWrapper}>
        <img src={logo} alt="Logo Clínica del Caribe" style={styles.logo} />
      </div>
      <div className="footer">
        <a href="https://facebook.com/clinicacaribe" target="_blank" rel="noopener noreferrer" style={{ ...styles.socialIcon, backgroundColor: '#3b5998' }}>
          <FaFacebook />
        </a>
        <a href="https://instagram.com/clinicacaribe" target="_blank" rel="noopener noreferrer" style={{ ...styles.socialIcon, backgroundColor: '#e4405f' }}>
          <FaInstagram />
        </a>
        <a href="https://twitter.com/clinicacaribe" target="_blank" rel="noopener noreferrer" style={{ ...styles.socialIcon, backgroundColor: '#1da1f2' }}>
          <FaTwitter />
        </a>
      </div>
    </div>
  );
}

const styles = {
  logoWrapper: {
    display: 'flex',
    justifyContent: 'center', // Centra el logo horizontalmente
    margin: '20px 0', // Espaciado arriba y abajo
  },
  logo: {
    maxWidth: '50%', // Logo reducido al 50%
    height: 'auto',
  },
  socialIcon: {
    color: '#fff', // Color de los íconos
    fontSize: '21.6px', // Tamaño reducido de los íconos (24px - 10%)
    padding: '8px', // Ajustado para tamaño reducido
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '36px', // Ajustado al 90% de 40px
    height: '36px', // Ajustado al 90% de 40px
    margin: '0 5px', // Espaciado entre íconos
  },
};

export default Home;
