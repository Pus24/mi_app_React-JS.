// src/components/Navigation.js
import React from "react";
import { Link } from "react-router-dom";

const LinkWithHover = ({ to, children }) => {
  const [hover, setHover] = React.useState(false);

  return (
    <Link
      to={to}
      style={{
        ...styles.link,
        ...(hover ? styles.linkHover : {}),
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {children}
    </Link>
  );
};

const Navigation = () => {
  return (
    <nav style={styles.nav}>
      <ul style={styles.ul}>
        <li style={styles.li}>
          <button style={styles.button}>
            <LinkWithHover to="/home">Home</LinkWithHover>
          </button>
        </li>
        <li style={styles.li}>
          <button style={styles.button}>
            <LinkWithHover to="/login">Login</LinkWithHover>
          </button>
        </li>
        <li style={styles.li}>
          <button style={styles.button}>
            <LinkWithHover to="/register">Register</LinkWithHover>
          </button>
        </li>
        <li style={styles.li}>
          <button style={styles.button}>
            <LinkWithHover to="/ver-usuarios">Ver Usuarios</LinkWithHover>
          </button>
        </li>
        <li style={styles.li}>
          <button style={styles.button}>
            <LinkWithHover to="/agendar-cita">Agendar Cita</LinkWithHover>
          </button>
        </li>
        <li style={styles.li}>
          <button style={styles.button}>
            <LinkWithHover to="/listar-citas">Listar Citas</LinkWithHover>
          </button>
        </li>
      </ul>
    </nav>
  );
};

const styles = {
  nav: {
    backgroundColor: '#282c34',
    padding: '1em',
    borderRadius: '8px',
  },
  ul: {
    listStyle: 'none',
    display: 'flex',
    gap: '15px',
    justifyContent: 'center',
    padding: 0,
    margin: 0,
  },
  li: {
    display: 'inline',
  },
  button: {
    backgroundColor: 'transparent',
    border: '2px solid #61dafb',
    borderRadius: '5px',
    cursor: 'pointer',
    padding: '10px 15px',
    outline: 'none',
    transition: 'background-color 0.3s, color 0.3s',
  },
  link: {
    color: '#ffffff', // Cambié a blanco
    textDecoration: 'none',
  },
  linkHover: {
    backgroundColor: '#61dafb',
    color: '#282c34',
  },
};

export default Navigation;
