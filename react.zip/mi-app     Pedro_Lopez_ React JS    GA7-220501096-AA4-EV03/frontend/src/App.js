// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import VerUsuarios from './components/VerUsuarios';
import AgendarCita from './components/AgendarCita';
import ListarCitas from './components/ListarCitas';
import Navigation from './components/Navigation';

function App() {
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleRegister = () => {
    setIsAuthenticated(true);
  };

  const handleCitaAgendada = () => {
    // Aquí puedes manejar el estado si necesitas realizar alguna acción
  };

  return (
    <Router>
      <Navigation />
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<Login onLogin={handleLogin} />} />
        <Route path="/register" element={<Register onRegister={handleRegister} />} />
        <Route path="/ver-usuarios" element={<VerUsuarios />} />
        <Route path="/agendar-cita" element={<AgendarCita onCitaAgendada={handleCitaAgendada} />} />
        <Route path="/listar-citas" element={isAuthenticated ? <ListarCitas /> : <Navigate to="/login" />} />
        <Route path="*" element={<Navigate to="/home" />} />
      </Routes>
    </Router>
  );
}

export default App;
